// Environment variables
// Default to the hardcoded URL if environment variable is not available
export const WEBHOOK_URL = import.meta.env.VITE_WEBHOOK_URL || "https://n8n.frayze.ca/webhook-test/d685ac24-5d07-43af-8311-bac8fbfe651d"; 